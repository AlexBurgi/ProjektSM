package com.burgholzer.shoppingapp;

import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.burgholzer.shoppingapp.model.Product;
import com.burgholzer.shoppingapp.service.ProductService;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainViewModel extends ViewModel {
    public static int MAINSCREEN = 1;
    public static int SETTINGS = 2;
    public static int SHARELIST = 3;
    public static int LISTDETAIL = 4;
    public static int NEWLIST = 5;
    public static int MAINCATEGORY = 6;
    public static int COOKING_SUBCATEGORY = 7;
    public static int HOUSEHOLD_SUBCATEGORY = 8;
    public static int ENTERTAINMENT_SUBCATEGORY = 9;
    public static int CHOOSEITEM = 10;
    public static int ADDITEM = 11;

    MutableLiveData<Integer> _state = new MutableLiveData<>(MAINSCREEN);
    LiveData<Integer> state = _state;
    public void showMainScreen(){
        _state.postValue(MAINSCREEN);
    }
    public void showSettings(){
        _state.postValue(SETTINGS);
    }
    public void showShareList(){
        _state.postValue(SHARELIST);
    }
    public void showListDetail(){
        _state.postValue(LISTDETAIL);
    }
    public void showNewList(){
        _state.postValue(NEWLIST);
    }
    public void showMainCategory(){
        _state.postValue(MAINCATEGORY);
    }
    public void showCookingSubCategory(){
        _state.postValue(COOKING_SUBCATEGORY);
    }
    public void showHouseholdSubcategory(){
        _state.postValue(HOUSEHOLD_SUBCATEGORY);
    }
    public void showEntertainmentSubcategory(){
        _state.postValue(ENTERTAINMENT_SUBCATEGORY);
    }
    public void showChooseItem(){
        _state.postValue(CHOOSEITEM);
    }
    public void showAddItem(){
        _state.postValue(ADDITEM);
    }

    //Settings
    private int darkmode = 0;

    public int getDarkmode() {
        return darkmode;
    }

    public void setDarkmode(int darkmode) {
        this.darkmode = darkmode;
    }

    //list name
    private String nameList;

    public String getNameList() {
        return nameList;
    }

    public void setNameList(String nameList) {
        this.nameList = nameList;
    }

    //Subcategory items
    //Fill items
    //cooking
    private MutableLiveData<List<Product>> fruits = new MutableLiveData<>(new ArrayList<>());
    private MutableLiveData<List<Product>> vegetables = new MutableLiveData<>(new ArrayList<>());
    private MutableLiveData<List<Product>> meat = new MutableLiveData<>(new ArrayList<>());
    private MutableLiveData<List<Product>> diaryProducts = new MutableLiveData<>(new ArrayList<>());
    private MutableLiveData<List<Product>> pastries = new MutableLiveData<>(new ArrayList<>());


    private MutableLiveData<Boolean> isLoading = new MutableLiveData<>(false);

    public LiveData<Boolean> getIsLoading() {
        return isLoading;
    }

    public void setIsLoading(boolean isLoading) {
        this.isLoading.setValue(isLoading);
    }

    public LiveData<List<Product>> getFruits() {
        return fruits;
    }

    public LiveData<List<Product>> getVegetables() {
        return vegetables;
    }

    public MutableLiveData<List<Product>> getMeat() {
        return meat;
    }

    public MutableLiveData<List<Product>> getDiaryProducts() {
        return diaryProducts;
    }

    public MutableLiveData<List<Product>> getPastries() {
        return pastries;
    }

    private int subcategory = 1;

    public int getSubcategory() {
        return subcategory;
    }

    public void setSubcategory(int subcategory) {
        this.subcategory = subcategory;
    }


    public void fetchProductsBySubcategoryId(int subcategoryId) {
        setIsLoading(true);
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://192.168.56.1:8080/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        ProductService service = retrofit.create(ProductService.class);
        Call<List<Product>> call = service.getProductsBySubcategoryId(subcategory);

        call.enqueue(new Callback<List<Product>>() {
            @Override
            public void onResponse(Call<List<Product>> call, Response<List<Product>> response) {
                if(response.isSuccessful()) {
                    Log.d("API Response Body:", response.body().toString());
                    setIsLoading(false);
                    List<Product> products = response.body();
                    Log.d("API Response:", products.toString()); // Log-Ausgabe hinzufügen

                    fruits.setValue(products);
                }
                else {
                    Log.d("API Response:", "Status Code: " + response.code() + " Message: " + response.message());
                }
            }

            @Override
            public void onFailure(Call<List<Product>> call, Throwable t) {
                setIsLoading(false);
                Log.d("API Failure:", t.getMessage());
            }
        });
    }

    //new list
    private String listName;

    public String getListName() {
        return listName;
    }

    public void setListName(String listName) {
        this.listName = listName;
    }

    //Category
    private int mainCategoryIdentifier;

    public int getMainCategoryIdentifier() {
        return mainCategoryIdentifier;
    }

    public void setMainCategoryIdentifier(int mainCategoryIdentifier) {
        this.mainCategoryIdentifier = mainCategoryIdentifier;
    }

    //choose item
    String productName;
    String image;

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    //add item to list
    private MutableLiveData<List<String>> listNames = new MutableLiveData<>(new ArrayList<>());
    private MutableLiveData<String> currentListName = new MutableLiveData<>();
    private MutableLiveData<List<Product>> currentListProducts = new MutableLiveData<>(new ArrayList<>());

    private Map<String, List<Product>> listProductsMap = new HashMap<>();

    public LiveData<List<String>> getListNames() {
        return listNames;
    }

    public LiveData<String> getCurrentListName() {
        return currentListName;
    }

    public LiveData<List<Product>> getCurrentListProducts() {
        return currentListProducts;
    }

    public void setCurrentListProducts(List<Product> products) {
        currentListProducts.setValue(products);
    }

    public void addListName(String listName) {
        List<String> currentList = listNames.getValue();
        if (currentList != null && !currentList.contains(listName)) {
            currentList.add(listName);
            listNames.setValue(currentList);
        }
    }

    public void setCurrentListName(String listName) {
        currentListName.setValue(listName);
        List<Product> products = getProductsForList(listName);
        currentListProducts.setValue(products);
    }

    public void addProductToCurrentList(Product product) {
        if (product != null) {
            String currentList = currentListName.getValue();
            if (currentList != null) {
                List<Product> products = listProductsMap.getOrDefault(currentList, new ArrayList<>());
                products.add(product);
                listProductsMap.put(currentList, products);
                currentListProducts.setValue(products);
                Log.d("MainViewModel", "Produkt hinzugefügt: " + product.getName());
            } else {
                Log.e("MainViewModel", "Aktuelle Liste der Produkte ist null.");
            }
        } else {
            Log.e("MainViewModel", "Produkt ist null und kann nicht zur Liste hinzugefügt werden.");
        }
    }

    public List<Product> getProductsForList(String listName) {
        return listProductsMap.getOrDefault(listName, new ArrayList<>());
    }


    public void finishAddingProducts() {
        List<String> currentLists = listNames.getValue();
        String listName = currentListName.getValue();
        if (listName != null && !listName.isEmpty() && !currentLists.contains(listName)) {
            currentLists.add(listName);
            listNames.setValue(currentLists);
        }
        _state.postValue(MAINSCREEN);
    }
    public void addListWithProducts(String listName, List<Product> products) {
        listProductsMap.put(listName, products);
        addListName(listName);
    }

    private int onClickBlocker = 0;

    public int getOnClickBlocker() {
        return onClickBlocker;
    }

    public void setOnClickBlocker(int onClickBlocker) {
        this.onClickBlocker = onClickBlocker;
    }

    //delete list
    public void deleteCurrentList() {
        String listName = currentListName.getValue();
        if (listName != null) {
            List<String> currentLists = listNames.getValue();
            currentLists.remove(listName);
            listNames.setValue(currentLists);

            listProductsMap.remove(listName);

            currentListName.setValue(null);
            currentListProducts.setValue(new ArrayList<>());
        }
    }
}
