package com.burgholzer.backend.shoppingApp.BackendShoppingApp;

import com.burgholzer.backend.shoppingApp.BackendShoppingApp.model.Category;
import com.burgholzer.backend.shoppingApp.BackendShoppingApp.model.Product;
import com.burgholzer.backend.shoppingApp.BackendShoppingApp.model.Subcategory;
import com.burgholzer.backend.shoppingApp.BackendShoppingApp.repository.CategoryRepository;
import com.burgholzer.backend.shoppingApp.BackendShoppingApp.repository.ProductRepository;
import com.burgholzer.backend.shoppingApp.BackendShoppingApp.repository.SubcategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.Arrays;
import java.util.List;

@SpringBootApplication
public class BackendShoppingAppApplication {
	@Autowired
	CategoryRepository categoryRepository;

	@Autowired
	SubcategoryRepository subcategoryRepository;

	@Autowired
	ProductRepository productRepository;
	public static void main(String[] args) {
		SpringApplication.run(BackendShoppingAppApplication.class, args);
	}

	@Bean
	CommandLineRunner commandLineRunner(){
		return (args -> {
			//categories
			Category cooking = new Category("Kochen");
			Category household = new Category("Haushalt");
			Category entertainment = new Category("Unterhaltung");
			categoryRepository.saveAll(Arrays.asList(cooking, household, entertainment));

			// Subcategories
			Subcategory fruit = new Subcategory("Obst", cooking);
			Subcategory vegatables = new Subcategory("Gemüse", cooking);
			Subcategory meat = new Subcategory("Fleisch", cooking);
			Subcategory diaryProducts = new Subcategory("Milchprodukte", cooking);
			Subcategory pastries = new Subcategory("Backwaren", cooking);
			subcategoryRepository.saveAll(Arrays.asList(fruit, vegatables, meat, diaryProducts, pastries));

			Subcategory houseHoldDevices = new Subcategory("Haushaltsgeräte", household);
			Subcategory kitchenItems = new Subcategory("Küchenutensilien", household);
			Subcategory furniture = new Subcategory("Möbel", household);
			Subcategory cleaningAgent = new Subcategory("Putzmittel", household);
			subcategoryRepository.saveAll(Arrays.asList(houseHoldDevices, kitchenItems, furniture, cleaningAgent));

			Subcategory moviesAndBooks = new Subcategory("Filme und Bücher", entertainment);
			Subcategory games = new Subcategory("Spiele", entertainment);
			Subcategory sport = new Subcategory("Sport", entertainment);
			subcategoryRepository.saveAll(Arrays.asList(moviesAndBooks, games, sport));
			// Items von fruit
			List<Product> fruitItems = Arrays.asList(
					new Product("Apfel", "apfel.png", fruit),
					new Product("Birne", "birne.png", fruit),
					new Product("Weintrauben", "weintrauben.png", fruit),
					new Product("Banane", "banane.png", fruit),
					new Product("Orange", "orange.png", fruit)
			);
			productRepository.saveAll(fruitItems);

			// Items from vegatable
			List<Product> vegatableItems = Arrays.asList(
					new Product("Tomate", "tomate.png", vegatables),
					new Product("Gurke", "gurke.png", vegatables),
					new Product("Karotte", "karotte.png", vegatables),
					new Product("Spinat", "spinat.png", vegatables)
			);
			productRepository.saveAll(vegatableItems);

			// Items from meat
			List<Product> meatItems = Arrays.asList(
					new Product("Huhn", "chicken.png", meat),
					new Product("Rindersteak", "steak.png", meat),
					new Product("Schweinefilet", "pork.png", meat)
			);
			productRepository.saveAll(meatItems);

			// Items from diary Prodcuts
			List<Product> diaryProductsItems = Arrays.asList(
					new Product("Milch", "milk.png", diaryProducts),
					new Product("Käse", "cheese.png", diaryProducts),
					new Product("Joghurt", "yoghurt.png", diaryProducts)
			);
			productRepository.saveAll(diaryProductsItems);

			// Items from patriesItems
			List<Product> pastriesItems = Arrays.asList(
					new Product("Brot", "bread.png", pastries),
					new Product("Semmel", "rolls.png", pastries),
					new Product("Croissant", "croissant.png", pastries)
			);
			productRepository.saveAll(pastriesItems);

			//Items from householdDeviceItem
			List<Product> householdDevicesItems = Arrays.asList(
					new Product("Mikrowelle", "microwave.png", houseHoldDevices),
					new Product("Wasserkocher", "kettle.png", houseHoldDevices),
					new Product("Toaster", "toaster.png", houseHoldDevices),
					new Product("Staubsauger", "vacuumcleaner.png", houseHoldDevices),
					new Product("Waschmaschine", "washingMachine.png", houseHoldDevices),
					new Product("Kühlschrank", "fridge.png", houseHoldDevices)
			);
			productRepository.saveAll(householdDevicesItems);

			//items for kitchenitems
			List<Product> kitchenItemsItems = Arrays.asList(
					new Product("Kochtopf", "cooking_pot.png", kitchenItems),
					new Product("Küchenmesser", "knife.png", kitchenItems),
					new Product("Küchenwaage", "scale.png", kitchenItems),
					new Product("Schneidebrett", "cuttingBoard.png", kitchenItems),
					new Product("Küchensieb", "sieve.png", kitchenItems)
			);
			productRepository.saveAll(kitchenItemsItems);

			//items for furnitureItems
			List<Product> furnitureItems = Arrays.asList(
					new Product("Bett", "bed.png", furniture),
					new Product("Schreibtisch", "desk.png", furniture),
					new Product("Stuhl", "chair.png", furniture),
					new Product("Sofa", "couch.png", furniture),
					new Product("Esstisch", "table.png", furniture),
					new Product("Schrank", "closet.png", furniture)
			);
			productRepository.saveAll(furnitureItems);

			//Items for cleaningAgentItems
			List<Product> cleaningAgentItems = Arrays.asList(
					new Product("Allzweckreiniger", "spray.png", cleaningAgent),
					new Product("Glasreiniger", "glasscleaner.png", cleaningAgent),
					new Product("Kloreiniger", "bathcleaner.png", cleaningAgent),
					new Product("Entkalker", "descaler.png", cleaningAgent),
					new Product("Lappen", "rag.png", cleaningAgent)
			);
			productRepository.saveAll(cleaningAgentItems);

			//movies
			List<Product> moviesAndBooksItems = Arrays.asList(
					new Product("DVD: The Godfather", "the_godfather.png", moviesAndBooks),
					new Product("Buch: Harry Potter", "harry_potter.png", moviesAndBooks),
					new Product("Blu-ray: Inception", "inception.png", moviesAndBooks),
					new Product("DVD: The Shawshank Redemption", "shawshank_redemption.png", moviesAndBooks),
					new Product("Buch: The Great Gatsby", "great_gatsby.png", moviesAndBooks),
					new Product("Blu-ray: Interstellar", "interstellar.png", moviesAndBooks)
			);
			productRepository.saveAll(moviesAndBooksItems);

			//games
			List<Product> gamesItems = Arrays.asList(
					new Product("Brettspiel: Settlers of Catan", "settlers_of_catan.png", games),
					new Product("Kartenspiel: Exploding Kittens", "exploding_kittens.png", games),
					new Product("Videospiel: Super Mario Odyssey", "super_mario_odyssey.png", games),
					new Product("Brettspiel: Monopoly", "monopoly.png", games),
					new Product("Kartenspiel: Uno", "uno.png", games),
					new Product("Videospiel: The Legend of Zelda", "zelda.png", games)
			);
			productRepository.saveAll(gamesItems);

			//sport
			List<Product> sportItems = Arrays.asList(
					new Product("Fußball", "football.png", sport),
					new Product("Basketball", "basketball.png", sport),
					new Product("Tennisschläger", "tennis.png", sport),
					new Product("Volleyball", "volleyball.png", sport)
			);
			productRepository.saveAll(sportItems);
		});
	}
}
