package com.burgholzer.backend.shoppingApp.BackendShoppingApp.Service;

import com.burgholzer.backend.shoppingApp.BackendShoppingApp.model.Subcategory;
import com.burgholzer.backend.shoppingApp.BackendShoppingApp.repository.SubcategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SubcategoryService {
    @Autowired
    private SubcategoryRepository subcategoryRepository;

    public List<Subcategory> getSubcategoriesByCategoryId(Long categoryId) {
        return subcategoryRepository.findByCategoryId(categoryId);
    }
}