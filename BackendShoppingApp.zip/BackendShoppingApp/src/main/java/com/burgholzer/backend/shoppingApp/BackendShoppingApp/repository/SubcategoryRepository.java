package com.burgholzer.backend.shoppingApp.BackendShoppingApp.repository;

import com.burgholzer.backend.shoppingApp.BackendShoppingApp.model.Subcategory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SubcategoryRepository extends CrudRepository<Subcategory, Integer> {
    List<Subcategory> findByCategoryId(Long categoryId);
}
