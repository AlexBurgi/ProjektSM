package com.burgholzer.backend.shoppingApp.BackendShoppingApp.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@NoArgsConstructor
@Getter
@Setter

@Entity
@Table(name = "category")
public class Category {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;
    private String name;
    public Category(String name){
        this.name = name;
    }

    @OneToMany(mappedBy = "category")
    @JsonIgnoreProperties("category")
    private List<Subcategory> subcategories;

}

