package com.burgholzer.backend.shoppingApp.BackendShoppingApp.Service;

import com.burgholzer.backend.shoppingApp.BackendShoppingApp.model.Category;
import com.burgholzer.backend.shoppingApp.BackendShoppingApp.repository.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CategoryService {
    @Autowired
    private CategoryRepository categoryRepository;

    public List<Category> getAllCategories() {
        Iterable<Category> categoriesIterable = categoryRepository.findAll();
        List<Category> categoriesList = new ArrayList<>();
        categoriesIterable.forEach(categoriesList::add);
        return categoriesList;
    }
}