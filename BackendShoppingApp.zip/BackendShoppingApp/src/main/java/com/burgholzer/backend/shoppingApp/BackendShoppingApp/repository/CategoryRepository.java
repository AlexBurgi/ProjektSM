package com.burgholzer.backend.shoppingApp.BackendShoppingApp.repository;

import com.burgholzer.backend.shoppingApp.BackendShoppingApp.model.Category;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CategoryRepository extends CrudRepository<Category, Integer> {

}
