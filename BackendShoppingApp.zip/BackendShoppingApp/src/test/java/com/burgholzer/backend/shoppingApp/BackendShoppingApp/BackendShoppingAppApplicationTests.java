package com.burgholzer.backend.shoppingApp.BackendShoppingApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendShoppingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
